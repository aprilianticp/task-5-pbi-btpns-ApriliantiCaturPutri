package router

import (
	"m-banking-api/app"
	"m-banking-api/controllers"
	"m-banking-api/middlewares"
)

func SetupRoutes() {
	api := app.Router

	// Rute untuk otentikasi
	api.POST("/users/register", controllers.Register)
	api.POST("/users/login", controllers.Login)

	// Middleware untuk memverifikasi token JWT
	api.Use(middlewares.Authenticate())

	// Rute untuk pengguna
	api.GET("/users/:userId", controllers.GetUser)
	api.POST("/photos", controllers.UploadPhoto)
	api.DELETE("/photos/:photoId", controllers.DeletePhoto)
}
