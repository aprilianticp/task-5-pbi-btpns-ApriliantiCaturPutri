package models

import (
	"gorm.io/gorm"
)

type Photo struct {
	gorm.Model
	UserID  uint
	Caption string
	// Tambahkan field lain sesuai kebutuhan
}
