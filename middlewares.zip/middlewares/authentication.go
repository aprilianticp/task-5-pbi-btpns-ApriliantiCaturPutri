package middlewares

import (
	"m-banking-api/app"
	"net/http"

	"github.com/gin-gonic/gin"
)

func Authenticate() gin.HandlerFunc {
	return func(c *gin.Context) {
		// Mendapatkan token JWT dari header Authorization
		tokenString := c.GetHeader("Authorization")
		if tokenString == "" {
			c.JSON(http.StatusUnauthorized, gin.H{"message": "Token is missing"})
			c.Abort()
			return
		}

		// Verifikasi token JWT
		claims, err := app.VerifyToken(tokenString)
		if err != nil {
			c.JSON(http.StatusUnauthorized, gin.H{"message": "Invalid token"})
			c.Abort()
			return
		}

		// Setel informasi pengguna yang terotentikasi dalam konteks
		c.Set("userId", claims.UserID)
		c.Next()
	}
}
