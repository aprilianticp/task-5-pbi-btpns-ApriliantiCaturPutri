// middlewares/error_handling.go

import (
	"github.com/gin-gonic/gin"
)

func ErrorHandler() gin.HandlerFunc {
	return func(c *gin.Context) {
		c.Next()

		// Tangani kesalahan setelah handler selesai
		errors := c.Errors.ByType(gin.ErrorTypeAny)

		if len(errors) > 0 {
			// Tangani kesalahan di sini
			// Misalnya, kirim respons JSON yang sesuai
			c.JSON(http.StatusInternalServerError, gin.H{"error": "Internal Server Error"})
		}
	}
}
