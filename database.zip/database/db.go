package database

import (
	"m-banking-api/models"
	"net/http"

	"github.com/gin-gonic/gin"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

var DB *gorm.DB

// database/db.go

func InitDB() {
	// Inisialisasi koneksi ke database SQLite (gantilah dengan konfigurasi database yang sesuai)
	db, err := gorm.Open(sqlite.Open("m-banking.db"), &gorm.Config{})
	if err != nil {
		panic("Failed to connect to database")
	}

	DB = db

	// Migrasi model-model Anda di sini
	DB.AutoMigrate(&models.User{}, &models.Photo{})
}

// controllers/auth_controller.go

func Register(c *gin.Context) {
	// ...

	// Simpan data pengguna ke database (contoh)
	newUser := models.User{
		Username: "newuser",
		Password: "password",
	}
	if err := database.DB.Create(&newUser).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to create user"})
		return
	}

	// ...
}
