package controllers

// controllers/auth_controller.go

import (
	"m-banking-api/helpers"
	"m-banking-api/models"
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/go-playground/validator/v10"
)

var validate *validator.Validate

func init() {
	validate = validator.New()
}

func Register(c *gin.Context) {
	// Validasi input pengguna
	var user models.User
	if err := c.ShouldBindJSON(&user); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// Simpan data pengguna ke database (contoh)
	newUser := models.User{
		Username: "newuser",
		Password: "password",
	}
	// Simpan newUser ke database
	// ...

	// Generate token JWT
	token, err := helpers.GenerateToken(newUser.ID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to generate token"})
		return
	}

	c.JSON(http.StatusCreated, gin.H{"token": token})
}

func Login(c *gin.Context) {
	// Implementasi logika login pengguna dan pembuatan token JWT
	// Contoh: Validasi login, verifikasi pengguna di database
	// Jika login sukses, Anda dapat menghasilkan token JWT
	// dan mengirimkannya sebagai respons
	// ...

	// Verifikasi pengguna (contoh)
	user := models.User{
		Username: "existinguser",
		Password: "password",
	}
	// Anda perlu mengecek user di database
	// ...

	// Check password (contoh)
	if user.Password != "password" {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "Invalid credentials"})
		return
	}

	// Generate token JWT
	token, err := helpers.GenerateToken(user.ID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to generate token"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"token": token})
}
