package controllers

import (
	"github.com/gin-gonic/gin"
)

func GetUser(c *gin.Context) {
	// Implementasi logika untuk mendapatkan data pengguna berdasarkan ID
}

func UploadPhoto(c *gin.Context) {
	// Implementasi logika untuk mengunggah foto oleh pengguna
}

func DeletePhoto(c *gin.Context) {
	// Implementasi logika untuk menghapus foto berdasarkan ID foto
}
