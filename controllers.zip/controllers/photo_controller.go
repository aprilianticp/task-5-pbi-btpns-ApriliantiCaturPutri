package controllers

import (
	"github.com/gin-gonic/gin"
)

type PhotoController struct{}

func (pc *PhotoController) UploadPhoto(c *gin.Context) {
	// Implement photo upload logic here
}

func (pc *PhotoController) DeletePhoto(c *gin.Context) {
	// Implement photo deletion logic here
}
