package helpers

import (
	"errors"
	"time"

	"github.com/dgrijalva/jwt-go"
	"github.com/gin-gonic/gin"
)

// Ganti kunci rahasia ini dengan yang lebih aman
var jwtSecret = []byte("april_123")

func GenerateToken(userID uint) (string, error) {
	claims := jwt.MapClaims{
		"userID": userID,
		"exp":    time.Now().Add(time.Hour * 24).Unix(), // Token berlaku selama 1 hari
		"iat":    time.Now().Unix(),
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	tokenString, err := token.SignedString(jwtSecret)
	if err != nil {
		return "", err
	}

	return tokenString, nil
}

func VerifyToken(tokenString string) (*jwt.MapClaims, error) {
	token, err := jwt.Parse(tokenString, func(token *jwt.Token) (interface{}, error) {
		return jwtSecret, nil
	})

	if err != nil {
		return nil, err
	}

	claims, ok := token.Claims.(jwt.MapClaims)
	if !ok || !token.Valid {
		return nil, err
	}

	return &claims, nil
}

func ExtractUserID(c *gin.Context) (uint, error) {
	claims, exists := c.Get("userId")
	if !exists {
		return 0, errors.New("User ID not found in context")
	}

	userID, ok := claims.(uint)
	if !ok {
		return 0, errors.New("Invalid user ID in context")
	}

	return userID, nil
}
