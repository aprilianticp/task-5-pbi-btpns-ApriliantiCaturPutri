package app

import (
	"m-banking-api/controllers"
)

func MapUrls() {
	authController := controllers.AuthController{}
	photoController := controllers.PhotoController{}

	authRoutes := Router.Group("/users")
	{
		authRoutes.POST("/register", authController.Register)
		authRoutes.POST("/login", authController.Login)
	}

	photoRoutes := Router.Group("/photos")
	{
		photoRoutes.POST("", photoController.UploadPhoto)
		photoRoutes.DELETE("/:photoId", photoController.DeletePhoto)
	}
}
