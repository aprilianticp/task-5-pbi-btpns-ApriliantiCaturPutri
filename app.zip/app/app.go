package app

import (
	"github.com/gin-gonic/gin"
)

var Router *gin.Engine

func Setup() {
	Router = gin.Default()
}
